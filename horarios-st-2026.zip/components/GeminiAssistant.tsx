import React from 'react';

// This component is currently disabled/unused to prevent build errors
// as the AI functionality was requested to be removed.
const GeminiAssistant: React.FC<any> = () => {
  return null;
};

export default GeminiAssistant;