import React from 'react';
// Este componente está vacío intencionalmente para evitar errores de build
const GeminiAssistant: React.FC<any> = () => {
  return null;
};
export default GeminiAssistant;